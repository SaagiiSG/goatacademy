"""Turn chosen word ranges into a padded, non-overlapping cut list, removing pauses inside them.

Usage:
  python3 make_cuts.py words.json audio.wav cuts.json --keep "0-41,48-120"   # word index ranges
  python3 make_cuts.py words.json audio.wav cuts.json --keep all             # keep everything, drop pauses
  python3 make_cuts.py words.json audio.wav - --print-speech                 # just list speech regions
"""
import argparse
import json
import re
import subprocess

PRE, POST = 0.08, 0.12

ap = argparse.ArgumentParser()
ap.add_argument("words")
ap.add_argument("wav")
ap.add_argument("out")
ap.add_argument("--keep", default="all")
ap.add_argument("--noise", default="-35dB", help="silence threshold")
ap.add_argument("--min-pause", type=float, default=0.35, help="pauses at least this long are removed")
ap.add_argument("--print-speech", action="store_true")
a = ap.parse_args()

words = json.load(open(a.words, encoding="utf-8"))["words"]
dur = float(subprocess.check_output(
    ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", a.wav]).strip())
log = subprocess.run(["ffmpeg", "-hide_banner", "-i", a.wav, "-af",
                      f"silencedetect=noise={a.noise}:d={a.min_pause}", "-f", "null", "-"],
                     capture_output=True, text=True).stderr
s_starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", log)]
s_ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", log)] + [dur]
speech, t = [], 0.0
for s, e in zip(s_starts, s_ends):
    if s > t:
        speech.append((t, s))
    t = e
if t < dur:
    speech.append((t, dur))

if a.print_speech:
    for s, e in speech:
        print(f"speech {s:7.2f} – {e:7.2f}")
    raise SystemExit

# 1. Word ranges -> time spans.
if a.keep.strip() == "all":
    ranges = [(0, len(words) - 1)]
else:
    ranges = [tuple(int(x) for x in r.split("-")) if "-" in r else (int(r), int(r))
              for r in a.keep.replace(" ", "").split(",") if r]
spans = []
for lo, hi in ranges:
    ws = [w for w in words[lo:hi + 1] if w.get("start") is not None]
    if ws:
        spans.append((ws[0]["start"], ws[-1]["end"], lo, hi))

# 2. Split each span at real pauses (intersect with speech regions).
pieces = []
for s, e, lo, hi in spans:
    for ss, se in speech:
        a0, b0 = max(s, ss), min(e, se)
        if b0 - a0 > 0.05:
            pieces.append([a0, b0])
pieces.sort()

# 3. Pad without overlap: if two pieces are too close for both pads, split the gap.
out = []
for i, (s, e) in enumerate(pieces):
    lo, hi = max(0.0, s - PRE), min(dur, e + POST)
    if i > 0:
        lo = max(lo, (pieces[i - 1][1] + s) / 2) if s - pieces[i - 1][1] < PRE + POST else lo
    if i + 1 < len(pieces) and pieces[i + 1][0] - e < PRE + POST:
        hi = (e + pieces[i + 1][0]) / 2
    if out and lo <= out[-1]["end"] + 1e-3:  # touching pieces merge into one
        out[-1]["end"] = round(hi, 3)
        continue
    out.append({"start": round(lo, 3), "end": round(hi, 3)})

for seg in out:
    seg["text"] = " ".join(w["word"] for w in words
                           if w.get("start") is not None and seg["start"] <= w["start"] < seg["end"])

json.dump({"segments": out}, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
kept = sum(x["end"] - x["start"] for x in out)
print(f"{len(out)} pieces | {kept:.1f}s kept of {dur:.1f}s -> {a.out}")
for i, x in enumerate(out, 1):
    print(f"{i:3}  {x['start']:7.2f} – {x['end']:7.2f}  ({x['end'] - x['start']:4.2f}s)  {x['text']}")
