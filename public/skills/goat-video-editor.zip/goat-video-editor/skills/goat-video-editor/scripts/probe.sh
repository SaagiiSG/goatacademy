#!/usr/bin/env bash
# Prints fps, size, rotation, duration and frame count of a clip.
ffprobe -v error -select_streams v:0 -show_entries \
  stream=codec_name,width,height,r_frame_rate,nb_frames:stream_side_data=rotation:format=duration \
  -of default=nw=1 "$1"
