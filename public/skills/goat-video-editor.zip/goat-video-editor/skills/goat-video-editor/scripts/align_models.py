"""Alignment models for languages WhisperX has no default for. None = WhisperX's own default."""
EXTRA = {
    "mn": "anton-l/wav2vec2-large-xlsr-53-mongolian",
}


def align_model_for(lang):
    return EXTRA.get(lang)
