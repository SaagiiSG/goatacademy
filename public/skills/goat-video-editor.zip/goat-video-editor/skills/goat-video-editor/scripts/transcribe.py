"""Transcribe audio with WhisperX large-v3 (CPU int8) and word-level alignment.
Usage: python transcribe.py transcript/audio.wav transcript/words.json [--lang mn]
The raw (pre-alignment) pass is cached next to the output as raw_segments.json."""
import argparse
import json
import os

import whisperx

from align_models import align_model_for

ap = argparse.ArgumentParser()
ap.add_argument("wav")
ap.add_argument("out")
ap.add_argument("--lang", default=None, help="force a language code; default: auto-detect")
a = ap.parse_args()

raw_path = os.path.join(os.path.dirname(a.out) or ".", "raw_segments.json")
audio = whisperx.load_audio(a.wav)
if os.path.exists(raw_path):
    result = json.load(open(raw_path))
else:
    model = whisperx.load_model("large-v3", "cpu", compute_type="int8", language=a.lang)
    result = model.transcribe(audio, batch_size=8)
    json.dump(result, open(raw_path, "w"), ensure_ascii=False, indent=1)
lang = result["language"]

model, meta = whisperx.load_align_model(language_code=lang, device="cpu", model_name=align_model_for(lang))
res = whisperx.align(result["segments"], model, meta, audio, "cpu", return_char_alignments=False)
words = [{"i": i, "word": w["word"], "start": w.get("start"), "end": w.get("end")}
         for i, w in enumerate(w for s in res["segments"] for w in s.get("words", []))]
json.dump({"language": lang, "text": " ".join(s["text"].strip() for s in res["segments"]), "words": words},
          open(a.out, "w"), ensure_ascii=False, indent=1)
print(f"{len(words)} words, language={lang} -> {a.out}")
print(" ".join(s["text"].strip() for s in res["segments"]))
