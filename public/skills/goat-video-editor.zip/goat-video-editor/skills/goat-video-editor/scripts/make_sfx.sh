#!/usr/bin/env bash
# Generates simple placeholder sound effects into the given folder (whoosh, pop, boom, tick).
set -e
d="${1:-edit/public}"; mkdir -p "$d"
ffmpeg -loglevel error -y -f lavfi -i "anoisesrc=d=0.45:c=pink:a=0.6" -af "highpass=f=300,lowpass=f=6000,afade=t=in:d=0.25:curve=exp,afade=t=out:st=0.25:d=0.2,volume=0.9" "$d/whoosh.wav"
ffmpeg -loglevel error -y -f lavfi -i "sine=f=880:d=0.09" -af "afade=t=out:d=0.09:curve=exp,volume=0.5" "$d/pop.wav"
ffmpeg -loglevel error -y -f lavfi -i "sine=f=140:d=0.35" -af "afade=t=out:d=0.35:curve=exp,volume=1.2" "$d/boom.wav"
ffmpeg -loglevel error -y -f lavfi -i "sine=f=1320:d=0.06" -af "afade=t=out:d=0.06,volume=0.25" "$d/tick.wav"
echo "SFX written to $d"
