#!/usr/bin/env bash
# Renders stills at the given cut-timeline seconds and joins them into one contact sheet.
# Usage: preview.sh <edit-dir> <out.png> <sec> [sec ...]
set -e
dir="$1"; out="$(cd "$(dirname "$2")" && pwd)/$(basename "$2")"; shift 2
fps=$(python3 -c "import json;print(json.load(open('$dir/src/video.json'))['fps'])")
tmp=$(mktemp -d); inputs=(); n=0
for s in "$@"; do
  fr=$(python3 -c "print(round($s*$fps))")
  (cd "$dir" && npx remotion still src/index.ts Edit "$tmp/s$n.png" --frame="$fr" --scale=0.25 --log=error)
  inputs+=(-i "$tmp/s$n.png"); n=$((n+1))
done
ffmpeg -loglevel error -y "${inputs[@]}" -filter_complex "hstack=inputs=$n" "$out" 2>/dev/null || cp "$tmp/s0.png" "$out"
rm -rf "$tmp"; echo "Preview -> $out"
