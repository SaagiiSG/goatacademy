"""Force-align a known script to the audio (no speech recognition), giving clean word timings.
Usage: python align_script.py transcript/audio.wav transcript/script.txt transcript/words.json --lang mn
Best for clips under ~3 minutes (aligned in one pass)."""
import argparse
import json

import whisperx

from align_models import align_model_for

ap = argparse.ArgumentParser()
ap.add_argument("wav")
ap.add_argument("script")
ap.add_argument("out")
ap.add_argument("--lang", default="mn")
a = ap.parse_args()

audio = whisperx.load_audio(a.wav)
text = " ".join(open(a.script, encoding="utf-8").read().split())
dur = len(audio) / 16000
model, meta = whisperx.load_align_model(language_code=a.lang, device="cpu", model_name=align_model_for(a.lang))
res = whisperx.align([{"start": 0.0, "end": dur, "text": text}], model, meta, audio, "cpu")
raw = [w for s in res["segments"] for w in s["words"]]

# Words the aligner couldn't place (often Latin words like "ChatGPT" in Mongolian text) get times
# interpolated between their neighbours so every word has a timestamp.
for i, w in enumerate(raw):
    if w.get("start") is None:
        prev = next((raw[j]["end"] for j in range(i - 1, -1, -1) if raw[j].get("end") is not None), 0.0)
        nxt = next((raw[j]["start"] for j in range(i + 1, len(raw)) if raw[j].get("start") is not None), dur)
        w["start"], w["end"], w["guessed"] = prev, nxt, True

words = [{"i": i, "word": w["word"], "start": round(w["start"], 3), "end": round(w["end"], 3),
          **({"guessed": True} if w.get("guessed") else {})} for i, w in enumerate(raw)]
json.dump({"language": a.lang, "text": text, "words": words}, open(a.out, "w"), ensure_ascii=False, indent=1)
guessed = sum(1 for w in words if w.get("guessed"))
print(f"{len(words)} words aligned ({guessed} interpolated) -> {a.out}")
