"""Render cuts.json to H.264/AAC in one ffmpeg pass, verify the frame count, and write cut-timeline data.

Usage: python3 render_cut.py raw/clip.MOV transcript/cuts.json output/cut.mp4 \
         --words transcript/words.json --data-out edit/src/video.json
Writes transcript/cut_words.json (word times on the cut timeline) next to --words."""
import argparse
import json
import math
import os
import subprocess
from fractions import Fraction

ap = argparse.ArgumentParser()
ap.add_argument("src")
ap.add_argument("cuts")
ap.add_argument("out")
ap.add_argument("--words")
ap.add_argument("--data-out")
a = ap.parse_args()


def probe(path, entries):
    return subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v:0", "-count_frames",
                                    "-show_entries", entries, "-of", "default=nw=1:nk=1", path], text=True).split()


fps = Fraction(probe(a.src, "stream=r_frame_rate")[0])
segs = json.load(open(a.cuts, encoding="utf-8"))["segments"]
# Snap to whole frames: start rounds down, end rounds up, end frame exclusive.
frames = [(math.floor(s["start"] * fps + 1e-6), math.ceil(s["end"] * fps - 1e-6)) for s in segs]
frames = [(x, max(y, x + 1)) for x, y in frames]

parts, labels = [], ""
for i, (x, y) in enumerate(frames):
    parts.append(f"[0:v]trim=start_frame={x}:end_frame={y},setpts=PTS-STARTPTS[v{i}]")
    parts.append(f"[0:a]atrim=start={float(x / fps):.6f}:end={float(y / fps):.6f},asetpts=PTS-STARTPTS[a{i}]")
    labels += f"[v{i}][a{i}]"
parts.append(f"{labels}concat=n={len(frames)}:v=1:a=1[v][a]")
os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
# -fps_mode passthrough keeps the footage's own frames; forcing -r would duplicate frames at the cuts.
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", a.src, "-filter_complex", ";".join(parts),
                "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "medium", "-crf", "17",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-fps_mode", "passthrough",
                "-movflags", "+faststart", a.out], check=True)

want = sum(y - x for x, y in frames)
got = int(probe(a.out, "stream=nb_read_frames")[0])
w, h = (int(v) for v in probe(a.out, "stream=width,height"))
print(f"{len(frames)} pieces | expected {want} frames ({float(want / fps):.2f}s) | rendered {got} "
      f"-> {'OK' if want == got else 'MISMATCH'}")

starts, acc = [], 0
for x, y in frames:
    starts.append(acc)
    acc += y - x

if a.data_out:
    os.makedirs(os.path.dirname(a.data_out) or ".", exist_ok=True)
    json.dump({"fps": float(fps), "width": w, "height": h, "total": acc, "pieceStarts": starts},
              open(a.data_out, "w"), indent=1)
    print(f"timeline data -> {a.data_out}")

if a.words:
    mapped = []
    for wd in json.load(open(a.words, encoding="utf-8"))["words"]:
        if wd.get("start") is None:
            continue
        for (x, y), off in zip(frames, starts):
            s, e = x / fps, y / fps
            if s <= wd["start"] < e:
                mapped.append({"i": wd.get("i"), "word": wd["word"],
                               "start": round(float(wd["start"] - s + off / fps), 3),
                               "end": round(float(min(wd["end"], e) - s + off / fps), 3)})
                break
    path = os.path.join(os.path.dirname(a.words), "cut_words.json")
    json.dump({"fps": float(fps), "duration": float(acc / fps), "words": mapped},
              open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{len(mapped)} words on the cut timeline -> {path}")
