#!/usr/bin/env bash
# Reports which tools the editor needs and how to install the missing ones.
os="$(uname -s)"
missing=0
ok()   { printf "  ✅ %-10s %s\n" "$1" "$2"; }
miss() { printf "  ❌ %-10s missing  ->  %s\n" "$1" "$2"; missing=1; }
inst() { if [ "$os" = "Darwin" ]; then echo "brew install $1"; else echo "winget install $2"; fi; }

echo "Goat Video Editor: setup check ($os)"
command -v ffmpeg  >/dev/null && ok ffmpeg  "$(ffmpeg -version | head -1 | cut -d' ' -f3)" || miss ffmpeg "$(inst ffmpeg Gyan.FFmpeg)"
command -v ffprobe >/dev/null && ok ffprobe "found" || miss ffprobe "(comes with ffmpeg)"
command -v uv      >/dev/null && ok uv      "$(uv --version | cut -d' ' -f2)" || miss uv "$(inst uv astral-sh.uv)"
if command -v node >/dev/null; then
  v=$(node -v | sed 's/v//' | cut -d. -f1)
  [ "$v" -ge 18 ] && ok node "$(node -v)" || miss node "Node $(node -v) is too old, need 18+: $(inst node OpenJS.NodeJS.LTS)"
else
  miss node "$(inst node OpenJS.NodeJS.LTS)"
fi
if command -v uv >/dev/null; then
  py=$(uv python find 3.11 2>/dev/null) && ok python3.11 "$py" || miss python3.11 "uv python install 3.11"
fi
venv=~/.cache/goat-video-editor/whisperx-venv
[ -d "$venv" ] && ok whisperx "$venv" || echo "  ⏳ whisperx   not set up yet (created in phase 1, one time)"
[ $missing = 0 ] && echo "All required tools are installed." || echo "Install the missing tools above, then run this check again."
