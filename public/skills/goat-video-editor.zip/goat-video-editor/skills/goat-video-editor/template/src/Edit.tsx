/*
 * EXAMPLE EDIT: a 44 s Mongolian talking head about AI ads (Odko's demo video).
 * For a new video, replace the timeline below with that video's approved graphics plan.
 * Times = seconds on the cut timeline (transcript/cut_words.json). Layer order = paint order.
 */
import { AbsoluteFill } from "remotion";
import {
  BaseVideo, Burst, Chip, Compare, Cutaway, Flash, FlowSteps, Grade, MapPins,
  PhoneChat, ProgressBar, Row, SearchBar, Sfx, THEME, TitleStamp, TopBand, fontFamily,
} from "./components";

// Big moments: zoom punch + shake. Pair each with a boom Sfx and, sparingly, a Burst.
const PUNCHES = [0.2, 3.71, 6.16, 37.48, 43.19];

export const Edit = () => (
  <AbsoluteFill style={{ background: "#000", fontFamily }}>
    {/* 1. Talking head + look */}
    <BaseVideo punches={PUNCHES} />
    <Grade />

    {/* 2. Hook: first 1.5 s decides whether people stay */}
    <Flash at={0.2} />
    <TopBand from={0.2} to={1.45}>
      <Chip color={THEME.hot} fill size={74}>😳 АЙМААР ЮМ</Chip>
    </TopBand>

    {/* 3. Top-band callouts build an idea word by word */}
    <TopBand from={1.65} to={5.55}>
      <Row>
        <Chip>🤖 AI</Chip>
        <Chip at={3.5} size={70}>+</Chip>
        <Chip at={3.71} color={THEME.hot} fill>📢 ЗАР</Chip>
      </Row>
      <Chip at={4.04} size={46}>AI дотроо шууд сурталчилгаа</Chip>
    </TopBand>

    {/* 4. Full-screen cutaway: kinetic title */}
    <Cutaway from={5.6} to={7.62}>
      <TitleStamp
        title={{ at: 5.82, text: "ChatGPT" }}
        stamp={{ at: 6.16, text: "ADS" }}
        subtitle={{ at: 6.72, text: "гарч ирж байна 👀" }}
      />
    </Cutaway>

    <TopBand from={7.64} to={8.5}>
      <Chip>🔍 Судалж үзлээ</Chip>
    </TopBand>

    <TopBand from={8.74} to={11.95}>
      <Chip size={46} color="#fff">ЖИШЭЭ НЬ 👇</Chip>
      <Row>
        <Chip at={10.07}>✂️ Үсчин</Chip>
        <Chip at={10.83}>🦷 Шүд</Chip>
      </Row>
    </TopBand>

    {/* 5. Phone mock-up: a question types in, the answer fills row by row */}
    <Cutaway from={11.95} to={18.42}>
      <PhoneChat
        question={{ text: "Манай гэрийн ойролцоо сайн үсчин байна уу?", from: 12.0, to: 12.95 }}
        answer={{ at: 13.25, title: "Энэ байна аа 👇", tag: "AD" }}
        rows={[
          { at: 13.25, icon: "📍", text: "Гэрийн ойролцоо" },
          { at: 13.97, icon: "⭐", text: "Review хамгийн өндөр" },
          { at: 15.58, icon: "₮", text: "Дажгүй үнэтэй" },
        ]}
        cta={{ at: 17.08, text: "✅ САНАЛ БОЛГОЖ БАЙНА" }}
      />
    </Cutaway>

    <TopBand from={18.42} to={19.3}>
      <Chip size={54} color="#fff">🧪 Би өөрөө туршлаа</Chip>
    </TopBand>
    <TopBand from={19.3} to={22.1}>
      <SearchBar text="3, 4-р хороо шүдний эмнэлэг" typeFrom={19.45} typeTo={21.2} />
    </TopBand>

    {/* 6. Map: places near the speaker */}
    <Cutaway from={22.1} to={27.6}>
      <MapPins
        title={{ at: 23.13, text: <>Бага байхаас явдаг <span style={{ color: THEME.accent }}>эмнэлгүүд</span> 🦷</> }}
        home={{ at: 22.12, icon: "🏠", label: "Манай гэр" }}
        pins={[
          { at: 24.45, icon: "🦷", x: 300, y: 700 },
          { at: 24.71, icon: "🦷", x: 800, y: 760 },
          { at: 24.95, icon: "🦷", x: 330, y: 1300 },
        ]}
        bubbles={[
          { at: 26.21, x: 90, y: 420, text: "⭐ Тэднийх нь ийм…" },
          { at: 26.73, x: 520, y: 480, text: "💬 …тэднийх нь тийм" },
        ]}
        banner={{ at: 25.07, text: "🤖 AI санал болгож байна" }}
      />
    </Cutaway>

    {/* 7. Before → after */}
    <TopBand from={28.1} to={30.7}>
      <Compare at={29.29} before={{ label: "Өмнө", icon: "🔎", text: "Google" }} after={{ label: "Ойрын жил", icon: "🤖", text: "AI" }} />
    </TopBand>

    {/* 8. Flow diagram: the payoff of the video */}
    <Cutaway from={30.7} to={38.8}>
      <FlowSteps
        steps={[
          { at: 30.79, icon: "💬", text: "Хүн AI-д асуудлаа ярина" },
          { at: 32.65, icon: "📢", text: "ChatGPT ads" },
          { at: 34.44, icon: "🦷", text: "“Наад эмнэлэг чинь сайн”" },
          { at: 36.74, icon: "🧲", text: "ШИНЭ ХЭРЭГЛЭГЧ", hot: true },
        ]}
        stamp={{ at: 37.48, text: "🔥 ШИНЭ УРСГАЛ" }}
      />
    </Cutaway>

    <TopBand from={38.86} to={40.6}>
      <Chip size={52}>🤔 Хүмүүс бодоод явж байхад…</Chip>
    </TopBand>
    <TopBand from={40.66} to={43.15}>
      <Chip color={THEME.hot} fill>⏳ УДАХГҮЙ</Chip>
      <Chip at={41.52} size={48}>👁 Нүдний ханиад шиг орж ирнэ</Chip>
    </TopBand>

    {/* 9. Ending */}
    <Flash at={43.19} color={THEME.accent} />
    <TopBand from={43.19} to={44.9}>
      <Chip fill size={60}>🚀 ШИНЭ СУВАГ ҮҮСЭЖ БАЙНА</Chip>
    </TopBand>

    {/* 10. Bursts on top of everything, then the progress bar */}
    <Burst at={0.3} y={520} emojis={["😳", "⚠️", "😱"]} />
    <Burst at={6.16} y={600} emojis={["💸", "📢", "💰"]} />
    <Burst at={37.48} y={200} emojis={["🔥", "🧲", "💸"]} />
    <Burst at={43.19} y={300} emojis={["🚀", "✨", "🔥"]} />
    <ProgressBar />

    {/* 11. Sound: whoosh ~0.15 s before each cutaway in/out, pop per callout, boom per punch */}
    <Sfx at={0.2} src="boom.wav" volume={0.6} />
    {[1.65, 7.64, 10.07, 10.83, 13.25, 13.97, 15.58, 18.42, 19.3, 25.07, 28.1, 30.79, 32.65, 34.44, 36.74, 38.86, 41.52].map((t) => (
      <Sfx key={t} at={t} src="pop.wav" />
    ))}
    {[3.71, 6.16, 17.08, 29.29, 37.48, 40.66, 43.19].map((t) => (
      <Sfx key={t} at={t} src="boom.wav" volume={0.45} />
    ))}
    {[5.45, 7.45, 11.8, 18.25, 21.95, 27.45, 30.55, 38.65].map((t) => (
      <Sfx key={t} at={t} src="whoosh.wav" volume={0.3} />
    ))}
    {[24.45, 24.71, 24.95].map((t) => (
      <Sfx key={t} at={t} src="tick.wav" />
    ))}
  </AbsoluteFill>
);
