/*
 * Goat Video Editor: motion graphics component library.
 * All times are SECONDS ON THE CUT TIMELINE (transcript/cut_words.json). Canvas is 1080x1920.
 * Catalog and usage rules: references/graphics-playbook.md
 */
import React, { createContext, useContext } from "react";
import {
  AbsoluteFill,
  Audio,
  Easing,
  OffthreadVideo,
  Sequence,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { loadFont } from "@remotion/google-fonts/Montserrat";
import video from "./video.json";

export const { fontFamily } = loadFont("normal", {
  weights: ["600", "800", "900"],
  subsets: ["latin", "cyrillic", "cyrillic-ext"], // cyrillic-ext carries Mongolian Ө and Ү
});

/* ---------- theme: change these to the creator's brand ---------- */
export const THEME = {
  accent: "#C8FF2E",
  hot: "#FF3355",
  blue: "#2F6BFF",
  card: "rgba(10,14,24,0.92)",
  line: "#2A3350",
  muted: "#9AA3B5",
  bg: "#0A0E17",
};
const VIDEO = staticFile("cut.mp4");

/** Seconds -> frame on the cut timeline. */
export const F = (s: number) => Math.round(s * video.fps);

/* ---------- timing context: children of TopBand / Cutaway know their start ---------- */
const BaseCtx = createContext<{ from: number; to: number }>({ from: 0, to: 0 });
const useBase = () => useContext(BaseCtx);

const popSpring = (f: number, fps: number, damping = 11) =>
  spring({ frame: f, fps, config: { damping, stiffness: 180, mass: 0.7 } });

/** Appears at absolute second `at` with a springy scale-in. Use inside TopBand or Cutaway. */
export const At: React.FC<{ at: number; style?: React.CSSProperties; children: React.ReactNode }> = ({ at, style, children }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { from } = useBase();
  const s = popSpring(f - (F(at) - F(from)), fps, 12);
  return (
    <div style={{ ...style, opacity: Math.min(1, s * 1.5), transform: `${style?.transform ?? ""} scale(${0.6 + 0.4 * s})` }}>
      {children}
    </div>
  );
};

/** Typewriter text between two absolute seconds, with a blinking cursor while typing. */
export const Typed: React.FC<{ text: string; from: number; to: number }> = ({ text, from, to }) => {
  const f = useCurrentFrame();
  const base = useBase().from;
  const n = Math.round(
    interpolate(f, [F(from) - F(base), F(to) - F(base)], [0, text.length], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
  );
  return (
    <>
      {text.slice(0, n)}
      {n < text.length && f % 16 < 8 ? "|" : ""}
    </>
  );
};

/* ---------- base layer ---------- */

/** The talking head. Alternates framing on every cut (hides jump cuts), slow push, punch + shake at `punches`. */
export const BaseVideo: React.FC<{ punches?: number[]; zoom?: number; focusY?: string }> = ({
  punches = [],
  zoom = 1.12,
  focusY = "42%",
}) => {
  const f = useCurrentFrame();
  const idx = video.pieceStarts.filter((s) => s <= f).length - 1;
  const start = video.pieceStarts[Math.max(0, idx)];
  let scale = (idx % 2 === 0 ? 1 : zoom) + interpolate(f - start, [0, 180], [0, 0.03], { extrapolateRight: "clamp" });
  let sx = 0;
  let sy = 0;
  for (const p of punches) {
    const d = f - F(p);
    if (d >= 0 && d < 20) {
      scale += 0.07 * Math.exp(-d / 5);
      const amp = 22 * Math.exp(-d / 3);
      sx += (random(`x${p}-${d}`) - 0.5) * amp;
      sy += (random(`y${p}-${d}`) - 0.5) * amp;
    }
  }
  return (
    <AbsoluteFill style={{ transform: `translate(${sx}px,${sy}px) scale(${scale})`, transformOrigin: `50% ${focusY}` }}>
      <OffthreadVideo src={VIDEO} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
    </AbsoluteFill>
  );
};

/** Film grain + vignette over everything below it. */
export const Grade: React.FC<{ grain?: number; vignette?: number }> = ({ grain = 0.09, vignette = 0.45 }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <AbsoluteFill style={{ background: `radial-gradient(ellipse at 50% 45%, transparent 55%, rgba(0,0,0,${vignette}) 100%)` }} />
      <svg width={1080} height={1920} style={{ position: "absolute", opacity: grain, mixBlendMode: "overlay" }}>
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={f % 12} />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};

export const ProgressBar: React.FC<{ color?: string }> = ({ color = THEME.accent }) => {
  const f = useCurrentFrame();
  return (
    <div style={{ position: "absolute", top: 0, left: 0, height: 10, width: `${(f / video.total) * 100}%`, background: color, boxShadow: `0 0 20px ${color}` }} />
  );
};

export const Flash: React.FC<{ at: number; color?: string }> = ({ at, color = "#fff" }) => (
  <Sequence from={F(at)} durationInFrames={6}>
    <FlashInner color={color} />
  </Sequence>
);
const FlashInner: React.FC<{ color: string }> = ({ color }) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{ background: color, opacity: interpolate(f, [0, 6], [0.55, 0]) }} />;
};

/** Sound effect at a second. Files from scripts/make_sfx.sh: whoosh.wav, pop.wav, boom.wav, tick.wav. */
export const Sfx: React.FC<{ at: number; src: string; volume?: number }> = ({ at, src, volume = 0.35 }) => (
  <Sequence from={F(at)} durationInFrames={30} layout="none">
    <Audio src={staticFile(src)} volume={volume} />
  </Sequence>
);

/** Emoji confetti exploding from (x, y). */
export const Burst: React.FC<{ at: number; x?: number; y?: number; emojis: string[]; count?: number }> = ({
  at, x = 540, y = 500, emojis, count = 14,
}) => (
  <Sequence from={F(at)} durationInFrames={26}>
    <BurstInner x={x} y={y} emojis={emojis} count={count} seed={at} />
  </Sequence>
);
const BurstInner: React.FC<{ x: number; y: number; emojis: string[]; count: number; seed: number }> = ({ x, y, emojis, count, seed }) => {
  const t = useCurrentFrame() / 26;
  const ease = 1 - Math.pow(1 - t, 3);
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {Array.from({ length: count }).map((_, i) => {
        const ang = random(`a${seed}-${i}`) * Math.PI * 2;
        const dist = 260 + random(`d${seed}-${i}`) * 380;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x + Math.cos(ang) * dist * ease - 40,
              top: y + Math.sin(ang) * dist * ease + 400 * t * t - 40,
              fontSize: 60 + random(`s${seed}-${i}`) * 40,
              opacity: interpolate(t, [0, 0.1, 0.7, 1], [0, 1, 1, 0]),
              transform: `rotate(${(random(`r${seed}-${i}`) - 0.5) * 360 * t}deg)`,
            }}
          >
            {emojis[i % emojis.length]}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

/* ---------- top band callouts (over the talking head) ---------- */

/** A stack of callouts in the free band above the head. Children appear/exit with the band. */
export const TopBand: React.FC<{ from: number; to: number; top?: number; children: React.ReactNode }> = ({
  from, to, top = 150, children,
}) => (
  <Sequence from={F(from)} durationInFrames={Math.max(1, F(to) - F(from))}>
    <BaseCtx.Provider value={{ from, to }}>
      <AbsoluteFill style={{ alignItems: "center", paddingTop: top, gap: 22, flexDirection: "column", fontFamily }}>
        {children}
      </AbsoluteFill>
    </BaseCtx.Provider>
  </Sequence>
);

/** Use inside a TopBand: lays chips side by side. */
export const Row: React.FC<{ children: React.ReactNode; gap?: number }> = ({ children, gap = 20 }) => (
  <div style={{ display: "flex", gap, alignItems: "center" }}>{children}</div>
);

const useBandPop = (at?: number) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { from, to } = useBase();
  const dur = F(to) - F(from);
  const s = popSpring(f - (at === undefined ? 0 : F(at) - F(from)), fps);
  const out = interpolate(f, [dur - 7, dur], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return { opacity: Math.min(1, s * 1.5) * (1 - out), transform: `translateY(${-50 * out}px) scale(${0.55 + 0.45 * s})` };
};

/** Pill callout. `at` = when it pops (defaults to the band start). `fill` = solid colour. */
export const Chip: React.FC<{ at?: number; color?: string; fill?: boolean; size?: number; children: React.ReactNode }> = ({
  at, color = THEME.accent, fill = false, size = 62, children,
}) => (
  <div
    style={{
      ...useBandPop(at),
      display: "inline-flex",
      alignItems: "center",
      gap: 18,
      padding: "22px 38px",
      borderRadius: 30,
      background: fill ? color : THEME.card,
      border: `4px solid ${color}`,
      color: fill ? THEME.bg : "#fff",
      fontSize: size,
      fontWeight: 900,
      letterSpacing: -1,
      boxShadow: `0 18px 50px rgba(0,0,0,0.45), 0 0 40px ${color}44`,
      whiteSpace: "nowrap",
    }}
  >
    {children}
  </div>
);

/** White search bar that types `text` (top band). */
export const SearchBar: React.FC<{ text: string; typeFrom: number; typeTo: number }> = ({ text, typeFrom, typeTo }) => (
  <div
    style={{
      ...useBandPop(),
      width: 900,
      display: "flex",
      alignItems: "center",
      gap: 24,
      background: "#fff",
      borderRadius: 60,
      padding: "30px 44px",
      fontSize: 52,
      fontWeight: 800,
      color: THEME.bg,
      boxShadow: "0 20px 60px rgba(0,0,0,0.45)",
    }}
  >
    <span>🔍</span>
    <span>
      <Typed text={text} from={typeFrom} to={typeTo} />
    </span>
  </div>
);

type Side = { label: string; icon: string; text: string };
/** Before → after card (top band). `before` gets struck through when `after` appears at `at`. */
export const Compare: React.FC<{ before: Side; after: Side; at: number }> = ({ before, after, at }) => {
  const f = useCurrentFrame();
  const { from } = useBase();
  const strike = interpolate(f, [F(at) - F(from), F(at) - F(from) + 8], [0, 100], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const box = (s: Side, on: boolean) => (
    <div
      style={{
        width: 360,
        padding: "22px 0",
        borderRadius: 28,
        textAlign: "center",
        position: "relative",
        background: on ? THEME.accent : THEME.card,
        color: on ? THEME.bg : "#fff",
        border: `4px solid ${on ? THEME.accent : THEME.line}`,
        boxShadow: on ? `0 0 50px ${THEME.accent}88` : "0 16px 40px rgba(0,0,0,0.45)",
      }}
    >
      <div style={{ fontSize: 34, fontWeight: 800, opacity: 0.75 }}>{s.label}</div>
      <div style={{ fontSize: 62, fontWeight: 900 }}>
        {s.icon} {s.text}
      </div>
      {!on && <div style={{ position: "absolute", left: 30, top: "58%", height: 8, width: `${strike * 0.8}%`, background: THEME.hot, borderRadius: 4 }} />}
    </div>
  );
  return (
    <div style={{ ...useBandPop(), display: "flex", alignItems: "center", gap: 24 }}>
      {box(before, false)}
      <span style={{ fontSize: 70, color: "#fff", fontWeight: 900 }}>→</span>
      <At at={at}>{box(after, true)}</At>
    </div>
  );
};

/* ---------- full-screen cutaways (B-roll replacement) ---------- */

/** Full-screen graphic scene; slides up in, down out. The speaker stays visible in a corner bubble. */
export const Cutaway: React.FC<{ from: number; to: number; pip?: boolean; children: React.ReactNode }> = ({ from, to, pip = true, children }) => (
  <Sequence from={F(from)} durationInFrames={Math.max(1, F(to) - F(from))}>
    <BaseCtx.Provider value={{ from, to }}>
      <CutawayInner from={from} to={to} pip={pip}>
        {children}
      </CutawayInner>
    </BaseCtx.Provider>
  </Sequence>
);
const CutawayInner: React.FC<{ from: number; to: number; pip: boolean; children: React.ReactNode }> = ({ from, to, pip, children }) => {
  const f = useCurrentFrame();
  const dur = F(to) - F(from);
  const y =
    interpolate(f, [0, 8], [100, 0], { extrapolateRight: "clamp", easing: Easing.out(Easing.cubic) }) +
    interpolate(f, [dur - 7, dur], [0, 100], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.in(Easing.cubic) });
  return (
    <AbsoluteFill style={{ transform: `translateY(${y}%)`, fontFamily }}>
      <AbsoluteFill style={{ background: `radial-gradient(circle at 50% 30%, #1B2440 0%, ${THEME.bg} 70%)` }} />
      <AbsoluteFill
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.045) 2px, transparent 2px), linear-gradient(90deg, rgba(255,255,255,0.045) 2px, transparent 2px)`,
          backgroundSize: "90px 90px",
          backgroundPosition: `0 ${-f * 1.5}px`,
        }}
      />
      {children}
      {pip && (
        <div style={{ position: "absolute", right: 50, bottom: 120, width: 280, height: 280, borderRadius: "50%", overflow: "hidden", border: `6px solid ${THEME.accent}`, boxShadow: "0 20px 50px rgba(0,0,0,0.6)" }}>
          <OffthreadVideo src={VIDEO} muted startFrom={F(from)} style={{ position: "absolute", width: 360, height: 640, left: -40, top: -150, objectFit: "cover" }} />
        </div>
      )}
    </AbsoluteFill>
  );
};

/** Big kinetic title: line 1, then a rotated stamp, then a subtitle. */
export const TitleStamp: React.FC<{
  title: { at: number; text: string };
  stamp?: { at: number; text: string; color?: string };
  subtitle?: { at: number; text: string };
  children?: React.ReactNode;
}> = ({ title, stamp, subtitle, children }) => (
  <AbsoluteFill style={{ alignItems: "center", paddingTop: 300 }}>
    <At at={title.at} style={{ fontSize: 140, fontWeight: 900, color: "#fff", letterSpacing: -4, textAlign: "center", padding: "0 60px" }}>
      {title.text}
    </At>
    {stamp && (
      <At
        at={stamp.at}
        style={{
          marginTop: 10,
          fontSize: 170,
          fontWeight: 900,
          color: "#fff",
          background: stamp.color ?? THEME.hot,
          padding: "0 50px",
          borderRadius: 24,
          transform: "rotate(-4deg)",
          boxShadow: `0 0 80px ${(stamp.color ?? THEME.hot)}88`,
        }}
      >
        {stamp.text}
      </At>
    )}
    {subtitle && (
      <At at={subtitle.at} style={{ marginTop: 50, fontSize: 60, fontWeight: 800, color: THEME.muted }}>
        {subtitle.text}
      </At>
    )}
    {children}
  </AbsoluteFill>
);

type RowItem = { at: number; icon: string; text: string };
/** Phone with a chat: user question types in, an answer card fills row by row, CTA button last. */
export const PhoneChat: React.FC<{
  header?: string;
  question: { text: string; from: number; to: number };
  answer: { at: number; title: string; tag?: string };
  rows: RowItem[];
  cta?: { at: number; text: string };
}> = ({ header = "🤖 AI чат", question, answer, rows, cta }) => (
  <AbsoluteFill style={{ alignItems: "center", paddingTop: 140 }}>
    <div style={{ width: 860, height: 1340, borderRadius: 70, background: "#0F1422", border: `10px solid ${THEME.line}`, padding: 46, boxSizing: "border-box", boxShadow: "0 40px 100px rgba(0,0,0,0.6)" }}>
      <div style={{ color: THEME.muted, fontSize: 36, fontWeight: 800, textAlign: "center", marginBottom: 40 }}>{header}</div>
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <div style={{ background: THEME.blue, color: "#fff", fontSize: 44, fontWeight: 700, padding: "26px 32px", borderRadius: "34px 34px 8px 34px", maxWidth: 640, minHeight: 60 }}>
          <Typed text={question.text} from={question.from} to={question.to} />
        </div>
      </div>
      <At at={answer.at} style={{ marginTop: 50, background: "#151B2B", borderRadius: 36, padding: 40, border: `3px solid ${THEME.accent}55` }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ color: "#fff", fontSize: 52, fontWeight: 900 }}>{answer.title}</span>
          {answer.tag && <span style={{ background: THEME.hot, color: "#fff", fontSize: 30, fontWeight: 900, padding: "8px 18px", borderRadius: 12 }}>{answer.tag}</span>}
        </div>
        {rows.map((r, i) => (
          <At key={i} at={r.at} style={{ display: "flex", alignItems: "center", gap: 20, fontSize: 48, fontWeight: 800, color: "#fff", marginTop: 26 }}>
            <span style={{ fontSize: 54 }}>{r.icon}</span>
            {r.text}
          </At>
        ))}
        {cta && (
          <At at={cta.at} style={{ marginTop: 44, background: THEME.accent, color: THEME.bg, fontSize: 54, fontWeight: 900, textAlign: "center", padding: "28px 0", borderRadius: 26, boxShadow: `0 0 60px ${THEME.accent}88` }}>
            {cta.text}
          </At>
        )}
      </At>
    </div>
  </AbsoluteFill>
);

/** Stylised map: home pin, other pins dropping in, speech bubbles, bottom banner. x/y in canvas px. */
export const MapPins: React.FC<{
  title?: { at: number; text: React.ReactNode };
  home: { at: number; icon: string; label: string; x?: number; y?: number };
  pins: { at: number; icon: string; x: number; y: number }[];
  bubbles?: { at: number; x: number; y: number; text: string }[];
  banner?: { at: number; text: string };
}> = ({ title, home, pins, bubbles = [], banner }) => {
  const f = useCurrentFrame();
  const ring = (f % 45) / 45;
  const hx = home.x ?? 540;
  const hy = home.y ?? 1000;
  const streets = [[0, 520, 1080, 470], [0, 980, 1080, 1060], [0, 1380, 1080, 1320], [260, 0, 330, 1920], [640, 0, 590, 1920], [900, 0, 980, 1920]];
  return (
    <AbsoluteFill>
      <svg width={1080} height={1920} style={{ position: "absolute" }}>
        {streets.map(([x1, y1, x2, y2], i) => (
          <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={THEME.line} strokeWidth={34} strokeLinecap="round" />
        ))}
        <circle cx={hx} cy={hy} r={120 + ring * 420} fill="none" stroke={THEME.accent} strokeWidth={5} opacity={1 - ring} />
      </svg>
      {title && (
        <At at={title.at} style={{ position: "absolute", top: 150, width: "100%", textAlign: "center", color: "#fff", fontSize: 64, fontWeight: 900 }}>
          {title.text}
        </At>
      )}
      <Pin {...home} x={hx} y={hy} color={THEME.accent} />
      {pins.map((p, i) => (
        <Pin key={i} {...p} color={THEME.blue} />
      ))}
      {bubbles.map((b, i) => (
        <At key={i} at={b.at} style={{ position: "absolute", left: b.x, top: b.y, background: "#fff", color: THEME.bg, fontSize: 44, fontWeight: 900, padding: "18px 28px", borderRadius: 24, boxShadow: "0 16px 40px rgba(0,0,0,0.5)" }}>
          {b.text}
        </At>
      ))}
      {banner && (
        <At at={banner.at} style={{ position: "absolute", bottom: 440, width: "100%", display: "flex", justifyContent: "center" }}>
          <div style={{ background: THEME.accent, color: THEME.bg, fontSize: 54, fontWeight: 900, padding: "24px 40px", borderRadius: 26 }}>{banner.text}</div>
        </At>
      )}
    </AbsoluteFill>
  );
};
const Pin: React.FC<{ at: number; x: number; y: number; icon: string; color: string; label?: string }> = ({ at, x, y, icon, color, label }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { from } = useBase();
  const s = spring({ frame: f - (F(at) - F(from)), fps, config: { damping: 9, stiffness: 160 } });
  return (
    <div style={{ position: "absolute", left: x - 70, top: y - 160, width: 140, opacity: Math.min(1, s * 2), transform: `translateY(${(1 - s) * -200}px)` }}>
      <div style={{ width: 140, height: 140, borderRadius: "50% 50% 50% 0", transform: "rotate(-45deg)", background: color, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 40px ${color}88` }}>
        <span style={{ transform: "rotate(45deg)", fontSize: 70 }}>{icon}</span>
      </div>
      {label && (
        <div style={{ position: "absolute", top: 160, left: "50%", transform: "translateX(-50%)", whiteSpace: "nowrap", color: "#fff", fontSize: 40, fontWeight: 900, background: THEME.card, padding: "8px 20px", borderRadius: 14 }}>
          {label}
        </div>
      )}
    </div>
  );
};

/** Vertical step-by-step flow; arrows grow into each step. Mark the payoff step `hot`. Max ~4 steps. */
export const FlowSteps: React.FC<{
  steps: { at: number; icon: string; text: string; hot?: boolean }[];
  stamp?: { at: number; text: string };
}> = ({ steps, stamp }) => {
  const f = useCurrentFrame();
  const { from } = useBase();
  return (
    <AbsoluteFill>
      {stamp && (
        <At at={stamp.at} style={{ position: "absolute", top: 120, width: "100%", display: "flex", justifyContent: "center", transform: "rotate(-3deg)" }}>
          <div style={{ background: THEME.hot, color: "#fff", fontSize: 66, fontWeight: 900, padding: "18px 40px", borderRadius: 22, boxShadow: `0 0 60px ${THEME.hot}88` }}>{stamp.text}</div>
        </At>
      )}
      {steps.map((st, i) => {
        const top = 330 + i * 290;
        const p = i === 0 ? 0 : interpolate(f, [F(st.at) - F(from) - 8, F(st.at) - F(from)], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        return (
          <React.Fragment key={i}>
            {i > 0 && <div style={{ position: "absolute", top: top - 80, left: 535, width: 10, height: 80 * p, background: THEME.accent, borderRadius: 5 }} />}
            <At
              at={st.at}
              style={{
                position: "absolute",
                top,
                left: 90,
                width: 900,
                height: 200,
                boxSizing: "border-box",
                display: "flex",
                alignItems: "center",
                gap: 30,
                padding: "0 44px",
                borderRadius: 34,
                background: st.hot ? THEME.accent : THEME.card,
                border: `4px solid ${st.hot ? THEME.accent : THEME.line}`,
                color: st.hot ? THEME.bg : "#fff",
                fontSize: st.hot ? 64 : 50,
                fontWeight: 900,
                boxShadow: st.hot ? `0 0 80px ${THEME.accent}99` : "0 16px 40px rgba(0,0,0,0.4)",
              }}
            >
              <span style={{ fontSize: 80 }}>{st.icon}</span>
              {st.text}
            </At>
          </React.Fragment>
        );
      })}
    </AbsoluteFill>
  );
};

/** Big number counting up (only for numbers the speaker actually said). */
export const StatCounter: React.FC<{ at: number; value: number; prefix?: string; suffix?: string; label: string; decimals?: number }> = ({
  at, value, prefix = "", suffix = "", label, decimals = 0,
}) => {
  const f = useCurrentFrame();
  const { from } = useBase();
  const t = interpolate(f, [F(at) - F(from), F(at) - F(from) + 24], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.cubic) });
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", paddingBottom: 300 }}>
      <At at={at} style={{ fontSize: 260, fontWeight: 900, color: THEME.accent, letterSpacing: -8, textShadow: `0 0 80px ${THEME.accent}66` }}>
        {prefix}
        {(value * t).toFixed(decimals)}
        {suffix}
      </At>
      <At at={at + 0.3} style={{ fontSize: 64, fontWeight: 900, color: "#fff", textAlign: "center", padding: "0 80px" }}>
        {label}
      </At>
    </AbsoluteFill>
  );
};

/** Checklist that ticks items one by one. */
export const Checklist: React.FC<{ title?: { at: number; text: string }; items: { at: number; text: string; bad?: boolean }[] }> = ({ title, items }) => (
  <AbsoluteFill style={{ padding: "260px 90px 0" }}>
    {title && (
      <At at={title.at} style={{ fontSize: 72, fontWeight: 900, color: "#fff", marginBottom: 50 }}>
        {title.text}
      </At>
    )}
    {items.map((it, i) => (
      <At key={i} at={it.at} style={{ display: "flex", alignItems: "center", gap: 30, fontSize: 56, fontWeight: 800, color: "#fff", background: THEME.card, border: `3px solid ${THEME.line}`, borderRadius: 28, padding: "30px 36px", marginBottom: 26 }}>
        <span style={{ width: 70, height: 70, borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", background: it.bad ? THEME.hot : THEME.accent, color: THEME.bg, fontSize: 48 }}>
          {it.bad ? "✕" : "✓"}
        </span>
        {it.text}
      </At>
    ))}
  </AbsoluteFill>
);
