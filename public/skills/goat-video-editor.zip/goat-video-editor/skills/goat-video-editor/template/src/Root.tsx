import { Composition } from "remotion";
import { Edit } from "./Edit";
import video from "./video.json";

// Always a 1080x1920 vertical canvas: graphics are laid out in these coordinates.
// Footage of any size is scaled to cover it (see BaseVideo).
export const Root = () => (
  <Composition id="Edit" component={Edit} durationInFrames={video.total} fps={video.fps} width={1080} height={1920} />
);
