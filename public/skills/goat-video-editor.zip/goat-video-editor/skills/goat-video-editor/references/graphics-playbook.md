# Graphics Playbook

How to plan and build the motion graphics for a short-form talking-head edit. Read this before writing `transcript/graphics_plan.md` and `edit/src/Edit.tsx`.

## Contents
1. Principles
2. Screen zones
3. Pacing rules
4. Component catalog
5. Sound design
6. Plan template
7. Build checklist

## 1. Principles

- **Graphics illustrate the words.** Every element lands on the word it shows (use `transcript/cut_words.json`), so the viewer hears and sees the idea at the same moment. A graphic that arrives late reads as random.
- **Never invent content.** Numbers, prices, names, ratings and claims come from the script only. Use generic labels for places and products ("Шүдний эмнэлэг", not "Smile Dental").
- **One idea per screen.** Short words, big type. A callout should say 1–5 words. If you need a sentence, it belongs in a cutaway.
- **The face is the product.** The talking head is the trust signal. Cutaways replace it for short bursts (2–8 s) and keep the speaker in the corner bubble.
- **Write the text in the speaker's language.** Keep their words and slang where possible: it's their voice.

## 2. Screen zones (1080 × 1920 canvas)

```
y 0–140      progress bar + safe margin (platform UI)
y 150–520    TOP BAND: callouts (TopBand / Chip / SearchBar / Compare)
y 520–1250   face: keep clear during talking-head shots
y 1250–1650  CAPTION ZONE: left empty; the creator adds captions in CapCut
y 1650–1920  platform UI (username, description): avoid
right-bottom corner bubble (PIP) during cutaways
```

If the creator's framing differs (face high in frame, or a lot of space below), adjust `TopBand top={...}` and `BaseVideo focusY`. Write the change in the project's `NOTES.md`.

Horizontal (16:9) footage is scaled to cover the vertical canvas, which crops the sides. Warn the student. Centered framing survives it, but off-center framing doesn't.

## 3. Pacing rules

- **0.0–1.5 s, the hook:** a flash, a punch-zoom and a bold red/filled chip on the hook phrase. A burst is optional.
- **Something changes every 2–4 s:** a new chip, a cut zoom (automatic) or a cutaway.
- **Full-screen cutaways:** 3–5 per minute, 2–8 s each. Start them about 0.1–0.2 s before the key word so the slide-in lands on it. Never stack two cutaways back to back without at least 0.5 s of face in between.
- **Punches (zoom + shake):** 4–6 per minute, only on the strongest words. More than that becomes noise.
- **Bursts:** 3–5 per video maximum.
- **The payoff** (the key insight, usually 70–85 % through) gets the biggest scene: usually FlowSteps or TitleStamp, plus a stamp and a burst.
- **The last 1.5 s:** a closing chip on the final line. A follow / CTA card only if the student asks for one.

## 4. Component catalog

All from `edit/src/components.tsx`. Times are cut-timeline seconds.

### Always on
| Component | Use |
|---|---|
| `<BaseVideo punches={[...]} />` | Talking head. Alternates 1.0 / 1.12 framing on every cut, slow push, punch + shake at each time in `punches`. |
| `<Grade />` | Film grain + vignette. Put it right after BaseVideo. |
| `<ProgressBar />` | Thin bar at the top. Last layer. |

### Top band (over the face shot)
```tsx
<TopBand from={1.65} to={5.55}>          // the whole group enters and exits together
  <Row>
    <Chip>🤖 AI</Chip>                   // pops at band start
    <Chip at={3.71} color={THEME.hot} fill>📢 ЗАР</Chip>   // pops on its word
  </Row>
  <Chip at={4.04} size={46}>longer line, smaller</Chip>
</TopBand>
```
- `Chip`: the workhorse. `fill` for emphasis, `color={THEME.hot}` for warnings and shocking points. Size 46–74.
- `SearchBar text typeFrom typeTo`: typing a search query. Good for "I searched for…".
- `Compare at before after`: "before → now", "them vs us", "old way → new way". The left side gets struck through.

### Cutaways (full screen, wrap each in `<Cutaway from to>`)
| Component | Best for | Key props |
|---|---|---|
| `TitleStamp` | A name, product, or shocking phrase | `title`, `stamp` (rotated red box), `subtitle` |
| `PhoneChat` | Anything about apps, AI, messages, searching | `question` (typed), `answer`, `rows[]`, `cta` |
| `MapPins` | Places, local business, "near me" | `home`, `pins[]`, `bubbles[]`, `banner`, `title` |
| `FlowSteps` | Process, funnel, cause → effect (≤ 4 steps) | `steps[]` (`hot` on the payoff), `stamp` |
| `StatCounter` | A number the speaker said | `value`, `prefix`, `suffix`, `label` |
| `Checklist` | Lists, do/don't, mistakes | `items[]` (`bad` for ✕) |

Inside a Cutaway you can also place free elements with `<At at={sec} style={{position:"absolute", ...}}>`.

### Accents
- `<Flash at color />`: white or accent flash. Use it on the hook and the ending.
- `<Burst at x y emojis={[...]} />`: emoji explosion. Place it after all cutaways so it renders on top.

### New components
If the video needs a visual the catalog lacks (a bar chart, a timeline, a price tag), add it to `components.tsx` following the same pattern: read `useBase()`, appear with `At`, use `THEME` colours. Keep it generic so the next video can reuse it.

## 5. Sound design

The files come from `scripts/make_sfx.sh`.

| Sound | When | Volume |
|---|---|---|
| `whoosh.wav` | about 0.15 s before each cutaway enters, and as it exits | 0.25–0.35 |
| `pop.wav` | each chip / row / step appearing | 0.3–0.35 |
| `boom.wav` | each punch, stamp, and the hook | 0.4–0.6 |
| `tick.wav` | small repeated items (pins dropping, typing) | 0.3 |

Keep the voice clearly on top: no more than about one sound per 0.5 s.

## 6. Plan template (`transcript/graphics_plan.md`)

```markdown
# Graphics plan: <video topic>
Hook: <the first line>   Payoff: <key insight + time>   Brand colours: <or default>

| # | Time (s) | Trigger word | Type | On-screen text / content |
|---|---|---|---|---|
| 1 | 0.20–1.45 | аймаар | TopBand Chip (hot, fill) + Flash + punch | 😳 АЙМААР ЮМ |
| 2 | 1.65–5.55 | AI / сурталчилгаа | TopBand Row | 🤖 AI + 📢 ЗАР |
| 3 | 5.60–7.62 | ChatGPT ads | Cutaway TitleStamp | ChatGPT / ADS / гарч ирж байна 👀 |
...
Punches: 0.2, 3.71, …   Bursts: 0.3 (😳⚠️😱), …
```

Show the student this table, not code.

## 7. Build checklist

1. `npx tsc --noEmit` passes.
2. Preview sheet (`scripts/preview.sh`) at the hook, at every cutaway, and on the payoff. Check that:
   - no text is cut off at the canvas edges or wraps badly;
   - nothing sits on the face during talking-head shots, and the caption zone is empty;
   - Mongolian letters Ө / Ү render (Montserrat with the cyrillic-ext subset);
   - the cutaway text is readable at phone size (≥ 44 px).
3. Full render. The frame count equals `video.json.total`.
4. Re-render only what changed when the student asks for tweaks. Scenes are independent, so edit the beat and re-render.
