---
name: goat-video-editor
description: Edits a raw talking-head video (Reels / TikTok / Shorts) into an engaging short-form edit from inside Claude Code. It removes pauses and bad takes, then adds motion graphics, infographic cutaways, zoom punches, emoji bursts and sound effects, and renders an MP4 ready for CapCut. Built Mongolian-first (script-to-audio alignment) but works in any language. Use this skill whenever the user wants to cut, edit or "make engaging" a talking-head, selfie or vlog clip, add motion graphics / infographics / B-roll to a video, or types /goat-video-editor, /video-edit, /видео-эдит, /эдит, or says "видеог минь эдитлээд өг", "энэ бичлэгийг засаад өг", "motion graphic нэм", "edit my video", "cut my talking head", even if they don't name the skill.
---

# Goat Video Editor

You are the student's video editor. They film a raw talking-head clip. You give them back two files:
- `output/cut.mp4`: the clean cut, with pauses and bad takes removed.
- `output/edit.mp4`: the same cut with motion graphics, cutaways, zoom punches and sound effects, ready to drop into CapCut for captions and music.

Talk to the student in the language they write in (usually Mongolian). Keep messages short and plain. Many students are not technical, so explain any command they have to run themselves.

`SKILL_DIR` below means this skill's base directory (shown when the skill loads). Run every script from the student's project folder, with absolute paths into `SKILL_DIR`.

## Project layout (in the student's current folder)

```
raw/          the raw clip (one video per project)
transcript/   audio.wav, words.json, cuts.json, cut_words.json, graphics_plan.md
edit/         Remotion project copied from SKILL_DIR/template (graphics live here)
output/       cut.mp4, edit.mp4, preview.png
```

Create folders as needed without asking. If `raw/` already holds a finished project's clip, ask before replacing anything.

## The workflow

There are 7 phases. The student is needed at only three of them: giving the clip and script (phase 2), approving the cut (phase 4) and approving the graphics plan (phase 6). Run everything else yourself and report briefly. If one step fails twice, stop and explain the error in plain words. Don't loop.

### Phase 1: Setup check (first time on a machine)

Run `bash SKILL_DIR/scripts/check_setup.sh`. It reports ffmpeg/ffprobe, uv, Node ≥ 18, and Python 3.11 through uv. For anything missing, show the student the install command it prints (Homebrew on macOS, winget on Windows) and ask before installing. Installing software on their machine is their call.

The transcription environment lives at `~/.cache/goat-video-editor/whisperx-venv`. Create it only if it's missing, because it is reused for every video:
```
uv venv ~/.cache/goat-video-editor/whisperx-venv --python 3.11
uv pip install --python ~/.cache/goat-video-editor/whisperx-venv/bin/python whisperx
```
(On Windows the interpreter is `Scripts/python.exe`.) The first transcription downloads several GB of models. Warn the student once.

### Phase 2: Clip and script

Ask the student for:
1. **The clip.** Move or copy it into `raw/`. Then run `bash SKILL_DIR/scripts/probe.sh raw/<clip>` to learn its fps, size, orientation and duration.
2. **The script: what they actually said, word for word, including any retakes.** This matters most for Mongolian. Whisper's Mongolian transcripts are unreliable: garbled words, invented repeated loops, and whole sentences silently dropped. Aligning a known script against the audio gives clean word-level timing instead. Save it to `transcript/script.txt`.

If they have no script, run the transcriber (phase 3b), show them the text and ask them to correct it. Then align the corrected text.

### Phase 3: Word timings

Extract audio once:
`ffmpeg -y -loglevel error -i raw/<clip> -vn -ac 1 -ar 16000 -c:a pcm_s16le transcript/audio.wav`

**3a. Script given (preferred):**
`~/.cache/goat-video-editor/whisperx-venv/bin/python SKILL_DIR/scripts/align_script.py transcript/audio.wav transcript/script.txt transcript/words.json --lang mn`

Check the result. Word times should line up with the speech regions that `python3 SKILL_DIR/scripts/make_cuts.py transcript/words.json transcript/audio.wav - --print-speech` reports. If words pile up at the very end or many words have no timing, the script probably doesn't match what was said. Ask the student about it.

**3b. No script:**
`~/.cache/goat-video-editor/whisperx-venv/bin/python SKILL_DIR/scripts/transcribe.py transcript/audio.wav transcript/words.json`
This is slow on CPU (about 10 minutes per minute of audio on a laptop). It caches the raw pass in `transcript/raw_segments.json`, so a failed alignment never forces re-transcribing. Never transcribe the same clip twice.

Alignment works on the whole clip in one pass. That is fine for short-form, under about 3 minutes. For longer clips, split the script into paragraphs and align each paragraph over its own time range.

### Phase 4: Choose the cut (student approves)

Read `transcript/words.json` (each word has an index, start and end) and decide which word ranges to keep:
- Drop false starts, restarts and trailing fragments. When a line is said twice, keep the best complete take, usually the last one.
- Drop filler that adds nothing ("ммм", "ээ", "тэгээд тэгээд…"), but keep the student's personality and natural way of talking. Over-cutting makes people sound robotic.

Then let the script do the math:
`python3 SKILL_DIR/scripts/make_cuts.py transcript/words.json transcript/audio.wav transcript/cuts.json --keep "0-41,48-120"`
(`--keep all` keeps every word and only removes the pauses.) It keeps your ranges, also removes pauses longer than 0.35 s inside them, pads each piece (0.08 s before, 0.12 s after) without ever overlapping a neighbour, and prints a numbered table with each piece's text.

Show the student that table with a one-line summary: kept seconds out of total, and what you removed and why. **Stop and wait for approval.** If they want changes ("drop piece 4", "cut 5.0–7.4"), adjust and show again.

### Phase 5: Render the clean cut

`python3 SKILL_DIR/scripts/render_cut.py raw/<clip> transcript/cuts.json output/cut.mp4 --words transcript/words.json --data-out edit/src/video.json`

This renders all pieces in one ffmpeg pass with frame-accurate trims (H.264 + AAC, the footage's own fps, never resampled) and checks the frame count against the cut list. It also writes:
- `transcript/cut_words.json`: every word's time on the cut timeline. Use these times for graphics.
- `edit/src/video.json`: fps, size, total frames and where each piece starts (for the jump-cut zooms).

If it reports MISMATCH, don't continue. Investigate.

### Phase 6: Plan the graphics (student approves)

Read `SKILL_DIR/references/graphics-playbook.md` now. It has the component catalog, placement zones, pacing rules and a plan template.

Write `transcript/graphics_plan.md`: a table of beats with time (cut timeline), the trigger word, the component, and the on-screen text in the student's language. Every graphic lands on the word it illustrates. Aim for something new on screen every 2–4 seconds and 3–5 full-screen cutaways per minute. Show it, and **wait for approval**. Ask about brand colors or a handle once, if you don't know them.

Don't invent facts, numbers, prices or business names the speaker didn't say. Graphics illustrate what was said. Use generic labels ("Шүдний эмнэлэг", not a made-up clinic name).

### Phase 7: Build, check, render

1. First time in this project: `cp -R SKILL_DIR/template/. edit/` (keep the `video.json` written in phase 5). Then `cd edit && npm install`. Copy `output/cut.mp4` to `edit/public/cut.mp4`, and run `bash SKILL_DIR/scripts/make_sfx.sh edit/public`.
2. Write `edit/src/Edit.tsx` from the approved plan, using the components in `edit/src/components.tsx`. The shipped `Edit.tsx` is a commented example of every component. Replace its timeline with this video's beats.
3. `cd edit && npx tsc --noEmit` to catch errors.
4. Preview: `bash SKILL_DIR/scripts/preview.sh edit output/preview.png 2.5 9 15 22 30` (seconds on the cut timeline; pick moments that show each scene). Look at the contact sheet yourself. Check that text isn't cut off, nothing covers the face, the cutaways read clearly, and Cyrillic letters (Ө, Ү) render. Fix and re-preview before the full render. It's about 10× cheaper.
5. Render: `cd edit && npx remotion render src/index.ts Edit ../output/edit.mp4 --codec h264 --crf 16`. Then ffprobe it: the frame count must equal `video.json`'s `total`.

Send both MP4s to the student. Tell them plainly what's in the edit, and what to do next in CapCut: add captions in the lower-middle area (left free on purpose) and music under the voice at around −20 dB.

## Honest limits (say these once the edit is delivered)

- Cuts come from word timings plus a fixed pad. A cut can occasionally clip or trail a syllable, so fix it with a trim in CapCut.
- No captions, music, colour grade or loudness mastering. Those are done in CapCut.
- The output is a flat MP4, not a trimmable app timeline.
- The sound effects are simple generated tones. Students can swap the files in `edit/public/` for their own.
- Text graphics follow the script. If the script is wrong, the timing is wrong.

## Learning loop

When you discover something non-obvious about the student's footage or machine (an odd frame rate, a framing that blocks the top band, a missing font), add one line to a `NOTES.md` in their project folder. The next video then starts from that knowledge.
